insert into trend.platform (id, created_time, updated_time, name)
values  (6, '2024-05-09 17:10:53.000000', '2024-05-09 17:10:53.000000', 'YOUTUBE');